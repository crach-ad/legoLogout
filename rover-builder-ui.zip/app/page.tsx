'use client'

import { useEffect, useState } from 'react'
import { LoginScreen } from '@/components/login-screen'
import { Dashboard } from '@/components/dashboard'
import { PartsSelection } from '@/components/parts-selection'
import { CartView } from '@/components/cart-view'
import { SubmitSuccess } from '@/components/submit-success'
import type { TeamProfile, CartItem } from '@/lib/types'

type Screen = 'login' | 'dashboard' | 'shop' | 'inventory' | 'success'

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login')
  const [teamProfile, setTeamProfile] = useState<TeamProfile | null>(null)

  useEffect(() => {
    const saved = localStorage.getItem('teamProfile')
    if (saved) {
      const profile = JSON.parse(saved)
      setTeamProfile(profile)
      setCurrentScreen('dashboard')
    }
  }, [])

  const handleLogin = (profile: TeamProfile) => {
    setTeamProfile(profile)
    localStorage.setItem('teamProfile', JSON.stringify(profile))
    setCurrentScreen('dashboard')
  }

  const handleAddToCart = (items: CartItem[]) => {
    if (!teamProfile) return
    
    const updatedCart = [...teamProfile.cart]
    items.forEach(newItem => {
      const existingIndex = updatedCart.findIndex(item => item.id === newItem.id)
      if (existingIndex >= 0) {
        updatedCart[existingIndex].quantity += newItem.quantity
      } else {
        updatedCart.push(newItem)
      }
    })

    const totalSpent = updatedCart.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const updated = { ...teamProfile, cart: updatedCart, spent: totalSpent }
    setTeamProfile(updated)
    localStorage.setItem('teamProfile', JSON.stringify(updated))
  }

  const handleRemoveFromCart = (itemId: string) => {
    if (!teamProfile) return
    
    const updatedCart = teamProfile.cart.filter(item => item.id !== itemId)
    const totalSpent = updatedCart.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const updated = { ...teamProfile, cart: updatedCart, spent: totalSpent }
    setTeamProfile(updated)
    localStorage.setItem('teamProfile', JSON.stringify(updated))
  }

  const handleSubmitBuild = () => {
    if (!teamProfile) return
    
    // Save to submissions
    const submissions = JSON.parse(localStorage.getItem('submissions') || '[]')
    submissions.push({
      ...teamProfile,
      timestamp: new Date().toISOString()
    })
    localStorage.setItem('submissions', JSON.stringify(submissions))
    
    // Clear team profile
    localStorage.removeItem('teamProfile')
    setTeamProfile(null)
    setCurrentScreen('success')
  }

  const handleNewTeam = () => {
    setCurrentScreen('login')
  }

  if (currentScreen === 'login') {
    return <LoginScreen onLogin={handleLogin} />
  }

  if (currentScreen === 'success') {
    return <SubmitSuccess onNewTeam={handleNewTeam} />
  }

  if (!teamProfile) return null

  if (currentScreen === 'dashboard') {
    return (
      <Dashboard
        profile={teamProfile}
        onNavigate={setCurrentScreen}
      />
    )
  }

  if (currentScreen === 'shop') {
    return (
      <PartsSelection
        profile={teamProfile}
        onAddToCart={handleAddToCart}
        onBack={() => setCurrentScreen('dashboard')}
      />
    )
  }

  if (currentScreen === 'inventory') {
    return (
      <CartView
        profile={teamProfile}
        onRemoveItem={handleRemoveFromCart}
        onBack={() => setCurrentScreen('dashboard')}
        onSubmit={handleSubmitBuild}
        onShop={() => setCurrentScreen('shop')}
      />
    )
  }

  return null
}
