'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Rocket, Zap, Star, Heart } from 'lucide-react'
import type { TeamProfile } from '@/lib/types'

const HOUSES = [
  { name: 'Lynx', icon: Zap, color: 'bg-yellow-400 hover:bg-yellow-500' },
  { name: 'Jaguar', icon: Star, color: 'bg-purple-400 hover:bg-purple-500' },
  { name: 'Cougar', icon: Heart, color: 'bg-pink-400 hover:bg-pink-500' },
  { name: 'Panther', icon: Rocket, color: 'bg-blue-400 hover:bg-blue-500' }
]

const ROVER_BUDGET = 200
const LANDSCAPE_BUDGET = 120

interface LoginScreenProps {
  onLogin: (profile: TeamProfile) => void
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [house, setHouse] = useState('')
  const [step, setStep] = useState(1)

  const handleStart = () => {
    if (!house) return

    const profile: TeamProfile = {
      grade: 1,
      house,
      teamName: `Team ${house}`,
      budget: ROVER_BUDGET + LANDSCAPE_BUDGET,
      spent: 0,
      cart: []
    }

    onLogin(profile)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-3xl space-y-8">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-2xl animate-bounce">
              <Rocket className="w-20 h-20 text-white" strokeWidth={3} />
            </div>
          </div>
          <h1 className="text-6xl font-black text-primary drop-shadow-lg" style={{ fontFamily: 'Comic Sans MS, cursive' }}>
            Mars Rover!
          </h1>
          {step === 1 && (
            <p className="text-3xl font-bold text-secondary">
              Pick Your Team!
            </p>
          )}
        </div>

        {step === 1 && (
          <div className="grid grid-cols-2 gap-6">
            {HOUSES.map(({ name, icon: Icon, color }) => (
              <button
                key={name}
                onClick={() => {
                  setHouse(name)
                  setStep(2)
                }}
                className={`${color} rounded-3xl p-12 shadow-2xl transform transition-all hover:scale-105 active:scale-95`}
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="w-24 h-24 bg-white/30 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <Icon className="w-16 h-16 text-white" strokeWidth={3} />
                  </div>
                  <span className="text-4xl font-black text-white drop-shadow-lg">
                    {name}
                  </span>
                </div>
              </button>
            ))}
          </div>
        )}

        {step === 2 && (
          <Card className="p-12 shadow-2xl bg-white/90 backdrop-blur">
            <div className="text-center space-y-8">
              <div className="space-y-4">
                <p className="text-4xl font-bold text-secondary">
                  You picked
                </p>
                <div className={`inline-block ${HOUSES.find(h => h.name === house)?.color} rounded-3xl px-12 py-6 shadow-xl`}>
                  <span className="text-5xl font-black text-white">
                    {house}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                <Button
                  onClick={handleStart}
                  size="lg"
                  className="w-full h-24 text-4xl font-black rounded-3xl shadow-2xl bg-gradient-to-r from-primary to-secondary hover:scale-105 transform transition-all"
                >
                  START! 🚀
                </Button>
                <Button
                  onClick={() => {
                    setHouse('')
                    setStep(1)
                  }}
                  variant="outline"
                  size="lg"
                  className="w-full h-20 text-3xl font-bold rounded-3xl"
                >
                  Go Back
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
